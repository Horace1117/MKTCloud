from horizon.test import helpers as test


class MonitorTests(test.TestCase):
    # Unit tests for monitor.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
