from horizon.test import helpers as test


class LogTests(test.TestCase):
    # Unit tests for log.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
