from horizon.test import helpers as test


class NoticeTests(test.TestCase):
    # Unit tests for notice.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
